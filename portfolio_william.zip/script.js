document.getElementById('botaoMensagem').addEventListener('click', () => {
  alert('Obrigado por visitar meu portfólio!');
});
